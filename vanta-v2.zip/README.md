# Vanta

Vanta, Android 9 ve üzeri için Türkçe, çevrimdışı sesli asistandır.

## GitHub Actions

1. `vanta-v2.zip` dosyasını GitHub deponun köküne yükle.
2. Ayrı verilen `build.yml` dosyasını varsayılan dalda `.github/workflows/build.yml` yoluna koy.
3. **Actions → Vanta APK → Run workflow** ile derlemeyi başlat. İş akışı kaynak ZIP’ini açar ve Türkçe modeli indirir. Tamamlanan çalışmanın **Artifacts** bölümündeki **Vanta-APK** arşivinden `Vanta.apk` dosyasını çıkar.

Yerel derleme için Java 17 ve Android SDK 35 ile önce `bash scripts/fetch-model.sh`, ardından `bash ./gradlew assembleDebug` çalıştır. Derleme modeli bir kez indirir ve SHA-256 özetini doğrular. [Türkçe Vosk modeli ve lisansı](https://alphacephei.com/vosk/models.html)

## Kullanım

- Vanta açıkken **Dinlemeyi başlat** düğmesine bas ve mikrofon ile bildirim izinlerini ver. Ekranı kilitlemeden önce “Hey asistan” bekleniyor durumunu gör. “Hey asistan” de ve komutunu söyle. Dinleme sürerken ekrandan veya bildirimden durdurabilirsin.
- **Saat 18:00 alarm kur** ve **Saat on sekiz alarm kur** komutları, cihazın saat diliminde o saatin ilk gelecek tekrarına alarm kurar. Vanta tarihi, günü ve saati gösterir. Android isterse **Alarmlar ve hatırlatıcılar** ile alarm bildirimlerine izin ver. Daha önce kurulan ve zamanı geçmemiş alarmlar, cihaz yeniden başladıktan ve ilk kilit açıldıktan sonra tekrar zamanlanır.
- Önce annenin numarasını kaydet. **Anneme selam mesajı at** komutu Vanta’da bir SMS taslağı hazırlar. Alıcıyı ve metni kontrol et, ardından **Mesajlar’da aç** düğmesine bas. Gönderme işlemini Mesajlar’da sen yaparsın. Bu adım için cihazda uyumlu bir SMS uygulaması gerekir.
- Aynı komutları **Komut yaz** alanında da kullanabilirsin.

Ses verisi cihazda işlenir. Dinleme sırasında kısa bir ses tamponu yalnızca bellekte tutulur. Kilit ekranı bildirimleri ve uzun süre ekran kapalıyken mikrofon erişimi cihazın Android ayarlarına bağlıdır. Dinleme açıkken mikrofon ve işlemci çalışır.
