#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")/.."
model=vosk-model-small-tr-0.3
sha256=8c8d07cec1bce31add14967c16891c84152cdf76d391e33c08278119b9ea96e5
destination="app/src/main/assets/$model.zip"
mkdir -p "$(dirname "$destination")"
if [[ -f "$destination" ]] && printf '%s  %s\n' "$sha256" "$destination" | sha256sum --check --status; then
  exit 0
fi

download="$(mktemp "$destination.XXXXXXXX")"
trap 'rm -f "$download"' EXIT
curl --fail --location --silent --show-error --retry 4 --connect-timeout 15 \
  --max-time 300 "https://alphacephei.com/vosk/models/$model.zip" -o "$download"
printf '%s  %s\n' "$sha256" "$download" | sha256sum --check
mv -f "$download" "$destination"
