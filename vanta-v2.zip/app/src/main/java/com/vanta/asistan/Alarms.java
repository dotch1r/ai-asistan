package com.vanta.asistan;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

final class Alarms {
    static final String FIRE = "com.vanta.asistan.FIRE_ALARM";
    static final String SAVED = "saved_alarms";

    static boolean canSchedule(Context context) {
        return Build.VERSION.SDK_INT < 31
                || context.getSystemService(AlarmManager.class).canScheduleExactAlarms();
    }

    private static Set<String> saved(Context context) {
        return new HashSet<>(AppData.prefs(context).getStringSet(SAVED, Collections.emptySet()));
    }

    static void add(Context context, long time) {
        register(context, time);
        Set<String> times = saved(context);
        times.add(Long.toString(time));
        save(context, times);
    }

    static boolean consume(Context context, long time) {
        Set<String> times = saved(context);
        if (!times.remove(Long.toString(time))) {
            return false;
        }
        save(context, times);
        return true;
    }

    static void cancel(Context context, long time) {
        context.getSystemService(AlarmManager.class).cancel(operation(context, time));
        consume(context, time);
    }

    static long next(Context context) {
        long now = System.currentTimeMillis();
        long next = Long.MAX_VALUE;
        for (String item : saved(context)) {
            long time = Long.parseLong(item);
            if (time > now) {
                next = Math.min(time, next);
            }
        }
        return next == Long.MAX_VALUE ? 0 : next;
    }

    static void restore(Context context) {
        if (!canSchedule(context)) {
            return;
        }
        long now = System.currentTimeMillis();
        Set<String> times = saved(context);
        if (times.removeIf(time -> Long.parseLong(time) <= now)) {
            save(context, times);
        }
        for (String item : times) {
            try {
                register(context, Long.parseLong(item));
            } catch (SecurityException exception) {
                return;
            }
        }
    }

    private static void save(Context context, Set<String> times) {
        SharedPreferences preferences = AppData.prefs(context);
        preferences.edit().putStringSet(SAVED, times).apply();
    }

    private static void register(Context context, long time) {
        AlarmManager manager = context.getSystemService(AlarmManager.class);
        manager.setAlarmClock(new AlarmManager.AlarmClockInfo(time, Notices.openApp(context)),
                operation(context, time));
    }

    private static PendingIntent operation(Context context, long time) {
        Intent intent = new Intent(context, AlarmReceiver.class)
                .setAction(FIRE)
                .setData(Uri.parse("vanta://alarm/" + time))
                .putExtra(AlarmSoundService.TIME, time);
        return PendingIntent.getBroadcast(context, 0, intent,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }
}
