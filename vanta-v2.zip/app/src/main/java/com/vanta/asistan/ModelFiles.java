package com.vanta.asistan;

import android.content.Context;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

final class ModelFiles {
    private static final String MODEL = "vosk-model-small-tr-0.3";

    static synchronized File prepare(Context context) throws IOException {
        File root = context.getNoBackupFilesDir();
        File model = new File(root, MODEL);
        if (model.isDirectory()) {
            return model;
        }
        File staging = new File(root, MODEL + "-staging");
        deleteTree(staging);
        makeDirectory(staging);
        try {
            unpack(context, staging);
            File extracted = new File(staging, MODEL);
            if (!new File(extracted, "final.mdl").isFile()
                    || !new File(extracted, "Gr.fst").isFile()) {
                throw new IOException("Eksik Türkçe ses modeli.");
            }
            if (!extracted.renameTo(model)) {
                throw new IOException("Türkçe model kaydedilemedi.");
            }
            return model;
        } finally {
            deleteTree(staging);
        }
    }

    private static void unpack(Context context, File staging) throws IOException {
        String rootPath = staging.getCanonicalPath() + File.separator;
        try (ZipInputStream zip = new ZipInputStream(context.getAssets().open(MODEL + ".zip"))) {
            byte[] buffer = new byte[32 * 1024];
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                File target = new File(staging, entry.getName());
                if (!target.getCanonicalPath().startsWith(rootPath)) {
                    throw new IOException("Geçersiz model dosyası yolu.");
                }
                if (entry.isDirectory()) {
                    makeDirectory(target);
                    continue;
                }
                makeDirectory(target.getParentFile());
                try (FileOutputStream output = new FileOutputStream(target)) {
                    int count;
                    while ((count = zip.read(buffer)) != -1) {
                        if (Thread.currentThread().isInterrupted()) {
                            throw new InterruptedIOException();
                        }
                        output.write(buffer, 0, count);
                    }
                }
            }
        }
    }

    private static void makeDirectory(File directory) throws IOException {
        if (!directory.isDirectory() && !directory.mkdirs()) {
            throw new IOException("Model klasörü açılamadı.");
        }
    }

    private static void deleteTree(File file) {
        File[] children = file.listFiles();
        if (children != null) {
            for (File child : children) {
                deleteTree(child);
            }
        }
        file.delete();
    }
}
