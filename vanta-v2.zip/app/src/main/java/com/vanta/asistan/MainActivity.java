package com.vanta.asistan;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputFilter;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public final class MainActivity extends Activity {
    private static final int REQUEST_VOICE = 10;
    private static final int REQUEST_ALARM_NOTICE = 11;
    private static final String ASKED_NOTICES = "asked_notices";
    private static final String ASKED_MIC = "asked_mic";
    private static final int BG = 0xFF11111A;
    private static final int PANEL = 0xFF1B1A29;
    private static final int INK = 0xFFF3F0FF;
    private static final int MUTED = 0xFFC5C0D6;
    private static final int ACCENT = 0xFFD2C9FF;
    private static final int DARK_ACCENT = 0xFF261952;

    private SharedPreferences preferences;
    private TextView voiceStatus;
    private Button voiceButton;
    private EditText commandInput;
    private TextView lastResult;
    private TextView alarmStatus;
    private Button alarmPermission;
    private Button alarmNotifications;
    private Button alarmCancel;
    private Button silence;
    private EditText numberInput;
    private LinearLayout draftCard;
    private TextView draftNumber;
    private TextView draftBody;

    private final Runnable voiceObserver = this::refreshVoice;
    private final SharedPreferences.OnSharedPreferenceChangeListener changes = (prefs, key) -> refresh();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        preferences = AppData.prefs(this);
        Notices.createChannels(this);
        buildUi();
    }

    @Override
    protected void onStart() {
        super.onStart();
        preferences.registerOnSharedPreferenceChangeListener(changes);
        VoiceService.observe(voiceObserver);
        refresh();
    }

    @Override
    protected void onResume() {
        super.onResume();
        AppData.tryPendingAlarm(this);
        refresh();
    }

    @Override
    protected void onStop() {
        VoiceService.unobserve(voiceObserver);
        preferences.unregisterOnSharedPreferenceChangeListener(changes);
        super.onStop();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            scroll.setOnApplyWindowInsetsListener((view, insets) -> {
                android.graphics.Insets safe = insets.getInsets(WindowInsets.Type.systemBars()
                        | WindowInsets.Type.displayCutout() | WindowInsets.Type.ime());
                view.setPadding(safe.left, safe.top, safe.right, safe.bottom);
                return WindowInsets.CONSUMED;
            });
        }

        FrameLayout center = new FrameLayout(this);
        scroll.addView(center);
        LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        column.setPadding(dp(20), dp(24), dp(20), dp(28));
        int width = Math.min(getResources().getDisplayMetrics().widthPixels, dp(720));
        center.addView(column, new FrameLayout.LayoutParams(width,
                FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.CENTER_HORIZONTAL));
        if (Build.VERSION.SDK_INT >= 30) {
            center.addOnLayoutChangeListener((view, left, top, right, bottom,
                    oldLeft, oldTop, oldRight, oldBottom) -> {
                int available = Math.min(right - left, dp(720));
                if (available > 0 && column.getLayoutParams().width != available) {
                    column.getLayoutParams().width = available;
                    column.requestLayout();
                }
            });
        }
        setContentView(scroll);

        add(column, title("Vanta", 34), 0);
        add(column, text("Türkçe sesli asistan", 16, MUTED), 2);

        LinearLayout voice = card(column, 22);
        add(voice, title("Sesli dinleme", 20), 0);
        voiceStatus = text("", 17, ACCENT);
        voiceStatus.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        add(voice, voiceStatus, 8);
        add(voice, text("Dinlemeyi başlat, “Hey asistan” de ve ardından komutunu söyle. Dinleme açıkken bildirimden de durdurabilirsin.", 15, MUTED), 6);
        voiceButton = button("", true, this::toggleVoice);
        add(voice, voiceButton, 14);

        LinearLayout command = card(column, 12);
        add(command, title("Komut yaz", 20), 0);
        commandInput = field("Komut", "Saat 18:00 alarm kur",
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES, 300);
        commandInput.setId(R.id.command_input);
        commandInput.setOnEditorActionListener((view, id, event) -> {
            if (id == EditorInfo.IME_ACTION_DONE) {
                runTyped();
                return true;
            }
            return false;
        });
        add(command, commandInput, 8);
        add(command, text("Saat on sekiz alarm kur\nAnneme selam mesajı at", 14, MUTED), 8);
        add(command, button("Komutu çalıştır", false, this::runTyped), 10);

        lastResult = text("", 16, INK);
        lastResult.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        lastResult.setTextIsSelectable(true);
        add(command, lastResult, 12);

        LinearLayout alarm = card(column, 12);
        add(alarm, title("Alarm", 20), 0);
        alarmStatus = text("", 16, MUTED);
        add(alarm, alarmStatus, 8);
        alarmPermission = button("Alarmlar ve hatırlatıcılar ayarını aç", false, this::openAlarmSettings);
        add(alarm, alarmPermission, 8);
        alarmNotifications = button("Alarm bildirimlerine izin ver", false, this::allowAlarmNotifications);
        add(alarm, alarmNotifications, 8);
        alarmCancel = button("Sıradaki alarmı iptal et", false, this::cancelAlarm);
        add(alarm, alarmCancel, 8);
        silence = button("Çalan alarmı sustur", true,
                () -> stopService(new Intent(this, AlarmSoundService.class)));
        add(alarm, silence, 8);

        LinearLayout sms = card(column, 12);
        add(sms, title("Anne · telefon numarası", 20), 0);
        numberInput = field("Annenin telefon numarası", "+90 5XX XXX XX XX", InputType.TYPE_CLASS_PHONE, 30);
        numberInput.setId(R.id.mother_number_input);
        numberInput.setText(preferences.getString(AppData.MOTHER_NUMBER, ""));
        add(sms, numberInput, 8);
        add(sms, button("Numarayı kaydet", false, this::saveNumber), 10);

        draftCard = card(column, 12);
        add(draftCard, title("SMS taslağı", 20), 0);
        draftNumber = text("", 16, ACCENT);
        draftNumber.setTextIsSelectable(true);
        add(draftCard, draftNumber, 8);
        draftBody = text("", 17, INK);
        draftBody.setTextIsSelectable(true);
        add(draftCard, draftBody, 8);
        add(draftCard, button("Mesajlar’da aç", true, this::openMessages), 12);
        add(draftCard, button("Taslağı sil", false, this::clearDraft), 8);

        column.setFocusableInTouchMode(true);
        column.requestFocus();
    }

    private void refresh() {
        refreshVoice();
        String result = preferences.getString(AppData.RESULT, "");
        lastResult.setText(result);
        visible(lastResult, !result.isEmpty());
        boolean canSchedule = Alarms.canSchedule(this);
        boolean hasNotices = Notices.enabled(this, Notices.ALARM_CHANNEL);
        long nextAlarm = Alarms.next(this);
        if (!canSchedule) {
            alarmStatus.setText("Kesin saatte çalması için Android’de Alarmlar ve hatırlatıcılar iznini aç.");
        } else if (!hasNotices) {
            alarmStatus.setText("Alarmı bildirimden görebilmek ve susturabilmek için bildirimlere izin ver.");
        } else if (nextAlarm > 0) {
            alarmStatus.setText("Sıradaki alarm\n" + AlarmTime.display(nextAlarm));
        } else {
            alarmStatus.setText("Kurulu alarm yok.");
        }
        visible(alarmPermission, !canSchedule);
        visible(alarmNotifications, !hasNotices);
        visible(alarmCancel, nextAlarm > 0);
        visible(silence, AlarmSoundService.ringing > 0);

        String number = preferences.getString(AppData.DRAFT_NUMBER, "");
        visible(draftCard, !number.isEmpty());
        draftNumber.setText("Alıcı (Anne)  " + number);
        draftBody.setText(preferences.getString(AppData.DRAFT_BODY, ""));
    }

    private void refreshVoice() {
        VoiceService.State state = VoiceService.state;
        voiceStatus.setText(state.label);
        voiceButton.setText(state == VoiceService.State.OFF ? "Dinlemeyi başlat" : "Dinlemeyi durdur");
    }

    private void toggleVoice() {
        if (VoiceService.state != VoiceService.State.OFF) {
            stopService(new Intent(this, VoiceService.class));
            return;
        }

        List<String> permissions = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            if (preferences.getBoolean(ASKED_MIC, false)
                    && !shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO)) {
                AppData.result(this, "Sesli komutlar için Vanta’nın Mikrofon iznini uygulama ayarlarından aç.");
                openSettings(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, packageUri()));
                return;
            }
            permissions.add(Manifest.permission.RECORD_AUDIO);
        }

        if (canRequestNotifications()) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS);
        } else if (!Notices.enabled(this, Notices.VOICE_CHANNEL)) {
            AppData.result(this, "Dinleme bildirimini görebilmek için Vanta bildirimlerini aç.");
            openSettings(Notices.notificationSettings(this, Notices.VOICE_CHANNEL));
            return;
        }
        if (permissions.isEmpty()) {
            startVoice();
        } else {
            SharedPreferences.Editor asked = preferences.edit();
            if (permissions.contains(Manifest.permission.RECORD_AUDIO)) {
                asked.putBoolean(ASKED_MIC, true);
            }
            if (permissions.contains(Manifest.permission.POST_NOTIFICATIONS)) {
                asked.putBoolean(ASKED_NOTICES, true);
            }
            asked.apply();
            AppData.result(this, "Sesli komutlar için mikrofon, dinleme durumunu görmek için bildirim izni gerekiyor.");
            requestPermissions(permissions.toArray(new String[0]), REQUEST_VOICE);
        }
    }

    private boolean canRequestNotifications() {
        return Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                && (!preferences.getBoolean(ASKED_NOTICES, false)
                    || shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS));
    }

    private void startVoice() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
                || !Notices.enabled(this, Notices.VOICE_CHANNEL)) {
            AppData.result(this, "Sesli dinleme için mikrofon ve bildirim izinlerini aç.");
            return;
        }
        try {
            startForegroundService(new Intent(this, VoiceService.class));
        } catch (RuntimeException exception) {
            AppData.result(this, "Dinleme başlatılamadı. Vanta açıkken tekrar dene.");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQUEST_VOICE) {
            startVoice();
        } else if (requestCode == REQUEST_ALARM_NOTICE) {
            AppData.tryPendingAlarm(this);
            refresh();
        }
    }

    private void allowAlarmNotifications() {
        if (canRequestNotifications()) {
            preferences.edit().putBoolean(ASKED_NOTICES, true).apply();
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_ALARM_NOTICE);
        } else {
            openSettings(Notices.notificationSettings(this, Notices.ALARM_CHANNEL));
        }
    }

    private void openAlarmSettings() {
        if (Build.VERSION.SDK_INT >= 31) {
            openSettings(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, packageUri()));
        }
    }

    private Uri packageUri() {
        return Uri.fromParts("package", getPackageName(), null);
    }

    private void openSettings(Intent intent) {
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException exception) {
            AppData.result(this, "Ayar ekranı açılamadı. Android ayarlarından Vanta’nın izinlerini kontrol et.");
        }
    }

    private void runTyped() {
        String command = commandInput.getText().toString().trim();
        if (command.isEmpty()) {
            commandInput.setError("Bir komut yaz.");
            return;
        }
        AppData.handle(this, command);
        hideKeyboard(commandInput);
    }

    private void cancelAlarm() {
        long next = Alarms.next(this);
        if (next > 0) {
            Alarms.cancel(this, next);
            AppData.result(this, "Alarm iptal edildi\n" + AlarmTime.display(next));
        }
    }

    private void saveNumber() {
        String number = numberInput.getText().toString().replaceAll("[\\s().-]+", "");
        if (!number.isEmpty() && !number.matches("\\+?[0-9]{3,15}")) {
            numberInput.setError("Geçerli bir telefon numarası gir.");
            return;
        }
        preferences.edit().putString(AppData.MOTHER_NUMBER, number).apply();
        numberInput.setText(number);
        AppData.result(this, number.isEmpty() ? "Kayıtlı numara kaldırıldı." : "Annenin numarası kaydedildi.");
        hideKeyboard(numberInput);
    }

    private void openMessages() {
        String number = preferences.getString(AppData.DRAFT_NUMBER, "");
        if (number.isEmpty()) {
            return;
        }
        Intent intent = new Intent(Intent.ACTION_SENDTO, Uri.fromParts("smsto", number, null));
        intent.putExtra("sms_body", preferences.getString(AppData.DRAFT_BODY, ""));
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException exception) {
            AppData.result(this, "Bu tablette SMS taslağı açabilen bir Mesajlar uygulaması bulunamadı.");
            android.widget.Toast.makeText(this, "Mesajlar uygulaması bulunamadı.", android.widget.Toast.LENGTH_LONG).show();
        }
    }

    private void clearDraft() {
        preferences.edit().remove(AppData.DRAFT_NUMBER).remove(AppData.DRAFT_BODY)
                .putString(AppData.RESULT, "SMS taslağı silindi.").apply();
    }

    private void hideKeyboard(View field) {
        getSystemService(InputMethodManager.class).hideSoftInputFromWindow(field.getWindowToken(), 0);
        field.clearFocus();
    }

    private LinearLayout card(LinearLayout parent, int top) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        card.setBackground(shape(PANEL, 18));
        add(parent, card, top);
        return card;
    }

    private TextView title(String content, int size) {
        TextView title = text(content, size, INK);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setAccessibilityHeading(true);
        return title;
    }

    private TextView text(String content, int size, int color) {
        TextView text = new TextView(this);
        text.setText(content);
        text.setTextSize(size);
        text.setTextColor(color);
        return text;
    }

    private Button button(String label, boolean primary, Runnable clicked) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextColor(primary ? DARK_ACCENT : INK);
        button.setMinimumHeight(dp(48));
        button.setPadding(dp(12), dp(8), dp(12), dp(8));
        button.setBackground(new RippleDrawable(ColorStateList.valueOf(0x306D52CD),
                shape(primary ? ACCENT : 0xFF34304A, 12), null));
        button.setOnClickListener(view -> clicked.run());
        return button;
    }

    private EditText field(String label, String hint, int inputType, int limit) {
        EditText input = new EditText(this);
        input.setContentDescription(label);
        input.setHint(hint);
        input.setSingleLine();
        input.setInputType(inputType);
        input.setImeOptions(EditorInfo.IME_ACTION_DONE);
        input.setFilters(new InputFilter[]{new InputFilter.LengthFilter(limit)});
        input.setTextSize(16);
        input.setTextColor(INK);
        input.setHintTextColor(MUTED);
        input.setBackground(shape(BG, 12));
        input.setMinimumHeight(dp(48));
        input.setPadding(dp(12), dp(8), dp(12), dp(8));
        return input;
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radius));
        return drawable;
    }

    private void add(LinearLayout parent, View child, int top) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        params.topMargin = dp(top);
        parent.addView(child, params);
    }

    private static void visible(View view, boolean visible) {
        view.setVisibility(visible ? View.VISIBLE : View.GONE);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
