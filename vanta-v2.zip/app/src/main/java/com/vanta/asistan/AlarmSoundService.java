package com.vanta.asistan;

import android.app.Notification;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.util.Log;

public final class AlarmSoundService extends Service {
    static final String TIME = "alarm_time";
    private static final String STOP = "com.vanta.asistan.STOP_ALARM";
    private static final int NOTIFICATION = 2;
    private static final long RING_DURATION_MS = 120_000;
    static long ringing;

    private final Handler main = new Handler(Looper.getMainLooper());
    private final Runnable timeout = this::stopSelf;
    private MediaPlayer player;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }

        long time = intent.getLongExtra(TIME, 0);
        if (time <= 0) {
            stopSelf();
            return START_NOT_STICKY;
        }

        Notices.createChannels(this);
        try {
            Notification notice = notification(time);
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIFICATION, notice, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            } else {
                startForeground(NOTIFICATION, notice);
            }
            if (player == null) {
                play();
            }
            ringing = time;
            AppData.result(this, "Alarm çalıyor\n" + AlarmTime.display(time));
            main.removeCallbacks(timeout);
            main.postDelayed(timeout, RING_DURATION_MS);
        } catch (RuntimeException exception) {
            Log.w("Vanta", "Alarm sesi başlatılamadı", exception);
            ringing = 0;
            AppData.result(this, "Alarm sesi başlatılamadı.\n" + AlarmTime.display(time));
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private void play() {
        AudioAttributes attributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        player = MediaPlayer.create(this, R.raw.alarm_tone, attributes,
                AudioManager.AUDIO_SESSION_ID_GENERATE);
        if (player == null) {
            throw new IllegalStateException("Alarm sesi yüklenemedi.");
        }
        player.setOnErrorListener((media, what, extra) -> {
            ringing = 0;
            AppData.result(this, "Alarm sesi çalınamadı.");
            stopSelf();
            return true;
        });
        player.setLooping(true);
        player.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK);
        player.start();
    }

    private Notification notification(long time) {
        Notification.Builder builder = new Notification.Builder(this, Notices.ALARM_CHANNEL)
                .setSmallIcon(R.drawable.ic_alarm)
                .setContentTitle("Vanta alarmı")
                .setContentText(AlarmTime.display(time))
                .setCategory(Notification.CATEGORY_ALARM)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setContentIntent(Notices.openApp(this))
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(null, "Alarmı sustur",
                        Notices.stopService(this, AlarmSoundService.class, STOP)).build());
        if (Build.VERSION.SDK_INT >= 31) {
            builder.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        }
        return builder.build();
    }

    @Override
    public void onDestroy() {
        main.removeCallbacks(timeout);
        if (player != null) {
            player.release();
            player = null;
        }
        if (ringing > 0) {
            ringing = 0;
            AppData.result(this, "Alarm sona erdi.");
        }
        stopForeground(STOP_FOREGROUND_REMOVE);
        super.onDestroy();
    }
}
