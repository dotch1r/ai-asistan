package com.vanta.asistan;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.zone.ZoneRules;

final class AlarmTime {
    private static final DateTimeFormatter DISPLAY =
            DateTimeFormatter.ofPattern("d MMMM yyyy EEEE · HH:mm", CommandParser.TURKISH);

    static long next(LocalTime time, ZonedDateTime now) {
        ZoneRules zoneRules = now.getZone().getRules();
        LocalDateTime candidate = now.toLocalDate().atTime(time);
        while (true) {
            for (ZoneOffset offset : zoneRules.getValidOffsets(candidate)) {
                Instant instant = candidate.toInstant(offset);
                if (instant.isAfter(now.toInstant())) {
                    return instant.toEpochMilli();
                }
            }
            candidate = candidate.plusDays(1);
        }
    }

    static String display(long millis) {
        return DISPLAY.format(Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()));
    }
}
