package com.vanta.asistan;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.Process;
import android.util.Log;

import org.json.JSONException;
import org.vosk.LibVosk;
import org.vosk.LogLevel;
import org.vosk.Model;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

public final class VoiceService extends Service {
    static final String STOP = "com.vanta.asistan.STOP_LISTENING";
    private static final int NOTIFICATION = 1;
    private static final Set<Runnable> observers = new HashSet<>();

    enum State {
        OFF("Dinleme kapalı"),
        LOADING("Türkçe ses modeli hazırlanıyor…"),
        WAITING("“Hey asistan” bekleniyor"),
        AWAKE("Seni dinliyorum. Komutunu söyle.");

        final String label;

        State(String label) {
            this.label = label;
        }
    }

    static State state = State.OFF;
    private final Handler main = new Handler(Looper.getMainLooper());
    private Thread worker;
    private boolean destroyed;

    static void observe(Runnable observer) {
        observers.add(observer);
    }

    static void unobserve(Runnable observer) {
        observers.remove(observer);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (worker != null) {
            return START_NOT_STICKY;
        }

        Notices.createChannels(this);
        try {
            Notification notification = notification(State.LOADING);
            if (Build.VERSION.SDK_INT >= 30) {
                startForeground(NOTIFICATION, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
            } else {
                startForeground(NOTIFICATION, notification);
            }
        } catch (RuntimeException exception) {
            Log.w("Vanta", "Mikrofon servisi başlatılamadı", exception);
            AppData.result(this, "Dinleme başlatılamadı. Vanta açıkken mikrofon ve bildirim izinlerini kontrol et.");
            stopSelf();
            return START_NOT_STICKY;
        }

        setState(State.LOADING);
        worker = new Thread(this::runVoice, "Vanta-Voice");
        worker.start();
        return START_NOT_STICKY;
    }

    private void runVoice() {
        PowerManager power = getSystemService(PowerManager.class);
        PowerManager.WakeLock wakeLock = power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Vanta:Listening");
        try {
            Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO);
            LibVosk.setLogLevel(LogLevel.WARNINGS);
            try (Model model = new Model(ModelFiles.prepare(this).getAbsolutePath())) {
                if (Thread.currentThread().isInterrupted()) {
                    return;
                }
                // İşlemci, kullanıcı dinlemeyi açık bıraktığı sürece ekran kapalıyken ses işleyebilir.
                wakeLock.acquire();
                new VoiceEngine(model, new VoiceEngine.Listener() {
                    @Override
                    public void waiting() {
                        post(() -> setState(State.WAITING));
                    }

                    @Override
                    public void awake() {
                        post(() -> setState(State.AWAKE));
                    }

                    @Override
                    public void command(String text) {
                        post(() -> AppData.handleSpeech(VoiceService.this, text));
                    }

                    @Override
                    public void timeout() {
                        post(() -> AppData.result(VoiceService.this, "Komut duyamadım. “Hey asistan” diyerek tekrar dene."));
                    }
                }).listen();
            }
        } catch (IOException | JSONException | RuntimeException | LinkageError exception) {
            if (!Thread.currentThread().isInterrupted()) {
                Log.w("Vanta", "Ses motoru durdu", exception);
                post(() -> {
                    AppData.result(this, "Ses motoru durdu. Mikrofon erişimini ve boş depolama alanını kontrol edip tekrar dene.");
                    stopSelf();
                });
            }
        } finally {
            if (wakeLock.isHeld()) {
                wakeLock.release();
            }
        }
    }

    private void post(Runnable action) {
        main.post(() -> {
            if (!destroyed) {
                action.run();
            }
        });
    }

    private void setState(State value) {
        if (state == value) {
            return;
        }
        state = value;
        for (Runnable observer : observers) {
            observer.run();
        }
        if (value != State.OFF && value != State.LOADING) {
            getSystemService(NotificationManager.class).notify(NOTIFICATION, notification(value));
        }
    }

    private Notification notification(State value) {
        Notification.Builder builder = new Notification.Builder(this, Notices.VOICE_CHANNEL)
                .setSmallIcon(R.drawable.ic_mic)
                .setContentTitle("Vanta dinliyor")
                .setContentText(value.label)
                .setContentIntent(Notices.openApp(this))
                .setCategory(Notification.CATEGORY_SERVICE)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .addAction(new Notification.Action.Builder(null, "Dinlemeyi durdur",
                        Notices.stopService(this, VoiceService.class, STOP)).build());
        if (Build.VERSION.SDK_INT >= 31) {
            builder.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        }
        return builder.build();
    }

    @Override
    public void onDestroy() {
        destroyed = true;
        if (worker != null) {
            worker.interrupt();
        }
        stopForeground(STOP_FOREGROUND_REMOVE);
        setState(State.OFF);
        super.onDestroy();
    }
}
