package com.vanta.asistan;

import java.text.Normalizer;
import java.time.LocalTime;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class CommandParser {
    static final Locale TURKISH = Locale.forLanguageTag("tr-TR");
    private static final Pattern WAKE = Pattern.compile(
            "^(?:hey|ey|hay)\\s+asistan(?=$|[\\s,!?.:])[,!?.:\\s]*",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern SMS = Pattern.compile(
            "^anneme\\s+(.+?)\\s+mesaj[ıi]?\\s+at$",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern ALARM = Pattern.compile("^saat (.+) alarm kur$");
    private static final Pattern MISHEARD_ALARM = Pattern.compile("^(saat .+) alan kur$");
    private static final Pattern NUMERIC_TIME = Pattern.compile("(\\d{1,2})\\s*[:.]\\s*(\\d{2})");
    private static final List<String> UNITS = Arrays.asList(
            "sifir", "bir", "iki", "uc", "dort", "bes", "alti", "yedi", "sekiz", "dokuz");
    private static final List<String> TENS = Arrays.asList(
            "", "on", "yirmi", "otuz", "kirk", "elli", "altmis", "yetmis", "seksen", "doksan");

    interface Command {}

    record Alarm(LocalTime time) implements Command {}

    record Sms(String body) implements Command {}

    static Command parse(String input) {
        String command = withoutWake(input).replaceFirst("[.!?]+$", "").trim();
        Matcher sms = SMS.matcher(command);
        if (sms.matches()) {
            return new Sms(sms.group(1).trim());
        }

        Matcher alarm = ALARM.matcher(fold(command));
        if (!alarm.matches()) {
            return null;
        }
        LocalTime time = parseTime(alarm.group(1));
        return time == null ? null : new Alarm(time);
    }

    static Command parseSpeech(String input) {
        String command = withoutWake(input);
        return parse(MISHEARD_ALARM.matcher(command).replaceFirst("$1 alarm kur"));
    }

    static String withoutWake(String input) {
        return WAKE.matcher(input.trim()).replaceFirst("").trim();
    }

    private static LocalTime parseTime(String input) {
        Matcher numeric = NUMERIC_TIME.matcher(input);
        if (numeric.matches()) {
            return time(Integer.parseInt(numeric.group(1)), Integer.parseInt(numeric.group(2)));
        }

        String[] words = input.split(" ");
        int hour = number(words, 0, words.length);
        if (hour >= 0) {
            return time(hour, 0);
        }
        for (int split = Math.min(2, words.length - 1); split > 0; split--) {
            hour = number(words, 0, split);
            int minute = number(words, split, words.length);
            if (words.length - split == 2 && words[split].equals("sifir")) {
                minute = UNITS.indexOf(words[split + 1]);
            }
            LocalTime candidate = time(hour, minute);
            if (candidate != null) {
                return candidate;
            }
        }
        return null;
    }

    private static int number(String[] words, int from, int to) {
        String first = words[from];
        if (to - from == 1) {
            if (first.matches("\\d{1,2}")) {
                return Integer.parseInt(first);
            }
            int unit = UNITS.indexOf(first);
            int tens = TENS.indexOf(first);
            return unit >= 0 ? unit : tens > 0 ? tens * 10 : -1;
        }
        if (to - from == 2) {
            int tens = TENS.indexOf(first);
            int unit = UNITS.indexOf(words[from + 1]);
            if (tens > 0 && unit > 0) {
                return tens * 10 + unit;
            }
        }
        return -1;
    }

    private static LocalTime time(int hour, int minute) {
        if (hour < 0 || hour > 23 || minute < 0 || minute > 59) {
            return null;
        }
        return LocalTime.of(hour, minute);
    }

    private static String fold(String input) {
        return Normalizer.normalize(input.toLowerCase(TURKISH), Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "")
                .replace('ı', 'i')
                .replaceAll("\\s+", " ");
    }
}
