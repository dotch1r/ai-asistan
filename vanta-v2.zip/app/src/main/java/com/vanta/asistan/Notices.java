package com.vanta.asistan;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;

final class Notices {
    static final String VOICE_CHANNEL = "vanta_listening";
    static final String ALARM_CHANNEL = "vanta_alarms";

    static void createChannels(Context context) {
        NotificationManager manager = context.getSystemService(NotificationManager.class);
        NotificationChannel listening = new NotificationChannel(
                VOICE_CHANNEL, "Mikrofon dinlemesi", NotificationManager.IMPORTANCE_LOW);
        listening.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        manager.createNotificationChannel(listening);

        NotificationChannel alarm = new NotificationChannel(
                ALARM_CHANNEL, "Vanta alarmları", NotificationManager.IMPORTANCE_HIGH);
        // Alarm sesi, etkin alarm bildirimiyle birlikte medya servisinde çalınır.
        alarm.setSound(null, null);
        alarm.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        manager.createNotificationChannel(alarm);
    }

    static boolean enabled(Context context, String channelId) {
        NotificationManager manager = context.getSystemService(NotificationManager.class);
        NotificationChannel channel = manager.getNotificationChannel(channelId);
        return manager.areNotificationsEnabled() && channel != null
                && channel.getImportance() != NotificationManager.IMPORTANCE_NONE;
    }

    static Intent notificationSettings(Context context, String channelId) {
        NotificationManager manager = context.getSystemService(NotificationManager.class);
        if (!manager.areNotificationsEnabled()) {
            return new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, context.getPackageName());
        }
        return new Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, context.getPackageName())
                .putExtra(Settings.EXTRA_CHANNEL_ID, channelId);
    }

    static PendingIntent openApp(Context context) {
        Intent intent = new Intent(context, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_IMMUTABLE);
    }

    static PendingIntent stopService(Context context, Class<?> service, String action) {
        Intent intent = new Intent(context, service).setAction(action);
        return PendingIntent.getService(context, 0, intent, PendingIntent.FLAG_IMMUTABLE);
    }
}
