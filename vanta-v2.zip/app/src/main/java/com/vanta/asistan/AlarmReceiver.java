package com.vanta.asistan;

import android.app.AlarmManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public final class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(action)
                || Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)
                || AlarmManager.ACTION_SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED.equals(action)) {
            Alarms.restore(context);
            return;
        }
        if (!Alarms.FIRE.equals(action)) {
            return;
        }

        long time = intent.getLongExtra(AlarmSoundService.TIME, 0);
        if (time > 0 && Alarms.consume(context, time)) {
            try {
                context.startForegroundService(new Intent(context, AlarmSoundService.class)
                        .putExtra(AlarmSoundService.TIME, time));
            } catch (RuntimeException exception) {
                Log.w("Vanta", "Alarm servisi başlatılamadı", exception);
                AppData.result(context, "Alarm sesi başlatılamadı.\n" + AlarmTime.display(time));
            }
        }
    }
}
