package com.vanta.asistan;

import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.SystemClock;

import org.json.JSONException;
import org.json.JSONObject;
import org.vosk.Model;
import org.vosk.Recognizer;

import java.io.IOException;

final class VoiceEngine {
    private static final int SAMPLE_RATE = 16000;
    private static final int FRAME_SAMPLES = SAMPLE_RATE / 10;
    private static final int PREROLL_FRAMES = 18;
    private static final long COMMAND_WINDOW_MS = 8500;
    private static final String WAKE_TEXT = "hey asistan";
    private static final String WAKE_GRAMMAR = "[\"hey asistan\", \"[unk]\"]";

    interface Listener {
        void waiting();
        void awake();
        void command(String text);
        void timeout();
    }

    private final Model model;
    private final Listener listener;

    VoiceEngine(Model model, Listener listener) {
        this.model = model;
        this.listener = listener;
    }

    void listen() throws IOException, JSONException {
        int minimum = AudioRecord.getMinBufferSize(
                SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        if (minimum <= 0) {
            throw new IOException("Mikrofon 16 kHz ses kaydını desteklemiyor.");
        }
        AudioRecord recorder = new AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION,
                SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                Math.max(minimum, FRAME_SAMPLES * 2 * 6));
        try (Recognizer wake = new Recognizer(model, SAMPLE_RATE, WAKE_GRAMMAR)) {
            if (recorder.getState() != AudioRecord.STATE_INITIALIZED) {
                throw new IOException("Mikrofon açılamadı.");
            }
            recorder.startRecording();
            if (recorder.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING) {
                throw new IOException("Mikrofon kaydı başlatılamadı.");
            }
            listener.waiting();
            processAudio(recorder, wake);
        } finally {
            recorder.release();
        }
    }

    private void processAudio(AudioRecord recorder, Recognizer wake)
            throws IOException, JSONException {
        // Bu tampon yalnızca aynı nefeste söylenen komutun başını korumak için RAM'de tutulur.
        short[][] frames = new short[PREROLL_FRAMES][FRAME_SAMPLES];
        int[] lengths = new int[PREROLL_FRAMES];
        int next = 0;
        int stored = 0;
        Recognizer command = null;
        long deadline = 0;
        try {
            while (!Thread.currentThread().isInterrupted()) {
                short[] frame = frames[next];
                int count = recorder.read(frame, 0, frame.length, AudioRecord.READ_BLOCKING);
                if (count < 0) {
                    throw new IOException("Mikrofon kaydı kesildi (" + count + ").");
                }
                if (count == 0) {
                    continue;
                }

                lengths[next] = count;
                next = (next + 1) % frames.length;
                stored = Math.min(stored + 1, frames.length);
                if (command == null) {
                    boolean endpoint = wake.acceptWaveForm(frame, count);
                    String candidate = endpoint ? text(wake.getResult(), "text")
                            : text(wake.getPartialResult(), "partial");
                    if (!WAKE_TEXT.equals(candidate)) {
                        if (endpoint) {
                            stored = 0;
                        }
                        continue;
                    }

                    listener.awake();
                    command = new Recognizer(model, SAMPLE_RATE);
                    deadline = SystemClock.elapsedRealtime() + COMMAND_WINDOW_MS;
                    int first = (next + frames.length - stored) % frames.length;
                    String replayed = "";
                    for (int i = 0; i < stored; i++) {
                        int index = (first + i) % frames.length;
                        if (command.acceptWaveForm(frames[index], lengths[index])) {
                            String recognized = text(command.getResult(), "text");
                            String withoutWake = CommandParser.withoutWake(recognized);
                            if (!recognized.equals(withoutWake) && CommandParser.parseSpeech(withoutWake) != null) {
                                replayed = withoutWake;
                            }
                        }
                    }
                    // Eski bir cümleyi komut saymamak için yalnızca uyandırma içeren sonucu kullan.
                    if (!replayed.isEmpty()) {
                        listener.command(replayed);
                    } else {
                        continue;
                    }
                } else {
                    boolean endpoint = command.acceptWaveForm(frame, count);
                    boolean expired = SystemClock.elapsedRealtime() >= deadline;
                    if (!endpoint && !expired) {
                        continue;
                    }

                    String json = endpoint ? command.getResult() : command.getFinalResult();
                    String transcript = CommandParser.withoutWake(text(json, "text"));
                    if (transcript.equals("asistan")) {
                        transcript = "";
                    }
                    if (transcript.isEmpty() && !expired) {
                        continue;
                    }
                    if (transcript.isEmpty()) {
                        listener.timeout();
                    } else {
                        listener.command(transcript);
                    }
                }

                command.close();
                command = null;
                wake.reset();
                stored = 0;
                listener.waiting();
            }
        } finally {
            if (command != null) {
                command.close();
            }
        }
    }

    private static String text(String json, String key) throws JSONException {
        return new JSONObject(json).optString(key, "").trim();
    }
}
