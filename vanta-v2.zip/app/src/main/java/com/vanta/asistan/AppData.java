package com.vanta.asistan;

import android.content.Context;
import android.content.SharedPreferences;

import java.time.LocalTime;
import java.time.ZonedDateTime;

final class AppData {
    static final String RESULT = "result";
    static final String MOTHER_NUMBER = "mother_number";
    static final String DRAFT_NUMBER = "draft_number";
    static final String DRAFT_BODY = "draft_body";
    static final String PENDING_ALARM = "pending_alarm";

    static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences("vanta", Context.MODE_PRIVATE);
    }

    static void result(Context context, String text) {
        prefs(context).edit().putString(RESULT, text).apply();
    }

    static void handle(Context context, String input) {
        handle(context, input, CommandParser.parse(input));
    }

    static void handleSpeech(Context context, String input) {
        handle(context, input, CommandParser.parseSpeech(input));
    }

    private static void handle(Context context, String input, CommandParser.Command command) {
        if (command instanceof CommandParser.Alarm alarm) {
            schedule(context, alarm.time());
        } else if (command instanceof CommandParser.Sms sms) {
            String number = prefs(context).getString(MOTHER_NUMBER, "");
            if (number.isEmpty()) {
                result(context, "Önce annenin numarasını kaydet, ardından komutu tekrar dene.");
                return;
            }
            prefs(context).edit()
                    .putString(DRAFT_NUMBER, number)
                    .putString(DRAFT_BODY, sms.body())
                    .putString(RESULT, "SMS taslağı hazır.")
                    .apply();
        } else {
            result(context, "Komut anlaşılamadı.\n" + input);
        }
    }

    static void schedule(Context context, LocalTime time) {
        long alarm = AlarmTime.next(time, ZonedDateTime.now());
        boolean exactAllowed = Alarms.canSchedule(context);
        boolean notifications = Notices.enabled(context, Notices.ALARM_CHANNEL);
        if (exactAllowed && notifications) {
            try {
                Alarms.add(context, alarm);
                prefs(context).edit()
                        .remove(PENDING_ALARM)
                        .putString(RESULT, "Alarm kuruldu\n" + AlarmTime.display(alarm))
                        .apply();
                return;
            } catch (SecurityException exception) {
                exactAllowed = false;
            }
        }
        String hint = exactAllowed
                ? "Alarm için bildirimlere izin ver."
                : "Alarm kurmak için Android ayarlarında Alarmlar ve hatırlatıcılar iznini aç.";
        prefs(context).edit()
                .putString(PENDING_ALARM, time.toString())
                .putString(RESULT, hint)
                .apply();
    }

    static void tryPendingAlarm(Context context) {
        String pending = prefs(context).getString(PENDING_ALARM, "");
        if (!pending.isEmpty() && Alarms.canSchedule(context)
                && Notices.enabled(context, Notices.ALARM_CHANNEL)) {
            schedule(context, LocalTime.parse(pending));
        }
    }
}
